
import json, os
import pandas as pd

file_name = "/filepath/relationships5000.json"

with open(file_name) as f:
     json_data = json.loads(f.read())
f.close()

df = pd.json_normalize(json_data, record_path=["relationships"], meta=["image_id"])
df.to_csv("/filepath/relationships5000.csv",index = False, header = False, sep=";")

