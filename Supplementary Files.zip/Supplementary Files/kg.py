pip install owlready2

from owlready2 import *
import csv, types


vr_ontology = get_ontology("/filepath/vrontology.owl").load(reload_if_newer = True)

f = open("/filepath/relationships-full5000.csv", newline='')
reader = csv.reader(f, delimiter=";")
next(reader)

with vr_ontology:

  for row in reader:
    sub, pred, obj, subx, suby, subw, subh, objx, objy, objw, objh, id = row

    relation = vr_ontology.Relation()
    relation.has_subject = vr_ontology.Subject(sub)
    relation.has_predicate = vr_ontology.Predicate(pred)
    relation.has_object = vr_ontology.Object(obj)

    relation.sub_x = int(subx)
    relation.sub_y = int(suby)
    relation.sub_w = int(subw)
    relation.sub_h = int(subh)

    relation.obj_x = int(objx)
    relation.obj_y = int(objy)
    relation.obj_w = int(objw)
    relation.obj_h = int(objh)

    relation.img = id

print(relation.has_subject, relation.has_predicate, relation.has_object)

vr_ontology.save("/filepath/kg.owl")
