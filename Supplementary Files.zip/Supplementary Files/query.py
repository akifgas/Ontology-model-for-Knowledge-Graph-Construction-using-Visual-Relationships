
ontology = get_ontology("/filepath/kg.owl").load(reload_if_newer = True)

s = "person"
p = "next to"
o = "car"

subject = ontology.Subject(s)
predicate = ontology.Predicate(p)
objct = ontology.Object(o)


list(default_world.sparql("""
           SELECT  ?relation ?subject ?predicate ?object ?sub_x ?sub_y ?sub_w ?sub_h ?obj_x ?obj_y ?obj_w ?obj_h
  WHERE {

    ?relation kg:has_subject ?? .
    ?relation kg:has_predicate ?? .
    ?relation kg:has_object ?? .

    ?relation kg:sub_x ?sub_x .
    ?relation kg:sub_y ?sub_y .
    ?relation kg:sub_w ?sub_w .
    ?relation kg:sub_h ?sub_h .

    ?relation kg:obj_x ?obj_x .
    ?relation kg:obj_y ?obj_y .
    ?relation kg:obj_w ?obj_w .
    ?relation kg:obj_h ?obj_h .

    ?relation kg:has_subject ?subject .
    ?relation kg:has_predicate ?predicate .
    ?relation kg:has_object ?object .

    }
    """,[subject,predicate,objct]))